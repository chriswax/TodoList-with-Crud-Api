﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TodoListWebApi.Data;
using TodoListWebApi.Models;

namespace TodoListWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoListController : Controller
    {
        private readonly TodoListWebApiDbContext dbContext;

        public TodoListController(TodoListWebApiDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllTodoLists()
        {
            return Ok(await dbContext.TodoLists.ToListAsync());
         
        }

        [HttpGet]
        [Route("{id:guid}")]
        public async Task<IActionResult> GetTodoList([FromRoute] Guid id)
        {
            var TodoList = await dbContext.TodoLists.FindAsync(id);
            if(TodoList == null)
            {
                return NotFound();
            }
            return Ok(TodoList);

        }

        [HttpPost]
        public async Task<IActionResult> CreateTodoList(AddTodoList addTodoList)
        {
            var TodoList = new TodoList()
            {
                Id = Guid.NewGuid(),
                Title = addTodoList.Title,
                Description = addTodoList.Description,
                DateAdded = DateTime.Now,
                DateModified = DateTime.Now,    
                IsDone = false,
            };

            await dbContext.TodoLists.AddAsync(TodoList);
            await dbContext.SaveChangesAsync();
            return Ok(TodoList); 
        }


        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateTodoList([FromRoute] Guid id, UpdateTodoList updateTodoList)
        {
            var todoList = await dbContext.TodoLists.FindAsync(id);
            if (todoList == null)
            {
                return NotFound();
            }

            todoList.Title = updateTodoList.Title;
            todoList.Description = updateTodoList.Description;
            todoList.IsDone = updateTodoList.IsDone;
            todoList.DateModified = DateTime.Now;
            await dbContext.SaveChangesAsync();
            return Ok(todoList);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteTodoList([FromRoute] Guid id) 
        {
            var todoList = await dbContext.TodoLists.FindAsync(id);
            if (todoList == null)
            {
                return NotFound();
            }
            dbContext.Remove(todoList);
            await dbContext.SaveChangesAsync();
            return Ok(todoList);

        }
    }
}
