﻿using Microsoft.EntityFrameworkCore;
using TodoListWebApi.Models;

namespace TodoListWebApi.Data
{
    public class TodoListWebApiDbContext : DbContext
    {
        public TodoListWebApiDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<TodoList> TodoLists { get; set; }
    }
}
