﻿namespace TodoListWebApi.Models
{
    public class AddTodoList
    {
        public string Title { get; set; }
        public string Description { get; set; }

    }
}
