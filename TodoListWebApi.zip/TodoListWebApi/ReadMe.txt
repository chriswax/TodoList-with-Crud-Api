TodoList Web API

This program is written with MS Visual Studio 2022, ASP.NET Core Web API


chriswax and pwd mWE7_Q:3rfGvBt:

Default domain:	chriswax.somee.com
Title:	chriswax Asp.net testing site
Description:	chriswax Asp.net testing site
Subscription:	Free hosting package (SPID1242690)
Service ID:	MPID4504429
Invoices:	INVID1337890
Hosting environment:	Windows Server 2022 (IIS 10.0, ASP, ASP.Net v2.0-4.8, ASP.Net Core)
Server local path:	d:\DZHosts\LocalUser\chriswax\www.chriswax.somee.com